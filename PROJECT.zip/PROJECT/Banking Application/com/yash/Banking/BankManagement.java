package com.yash.Banking;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.Scanner;
 
public class BankManagement 
{ 
	private static final int NULL = 0;
 
    static Connection con = Connection1.getConnection();
    static String sql = "";
    public static boolean createAccount(String name,int pass_Code) 
    {
        try {
			if (name == "" || pass_Code == NULL) 
			{
                System.out.println("All Field Required!");
                return false;
            }
            
            Statement st = con.createStatement();
            String sql = "INSERT INTO customer(cname,balance,pass_code) values('"+ name + "',1000," + pass_Code + ")";
 
            if (st.executeUpdate(sql) == 1) 
			{
				System.out.println(name + ", Now You can Login!");
                return true;
            }
            
        }
        catch (SQLIntegrityConstraintViolationException e) 
		{
            System.out.println("Username Not Available!");
        }
	
        catch (Exception e) 
		{
            e.printStackTrace();
        }
        return false;
    }
    public static boolean loginAccount(String name, int passCode)
    {
        try 
		{

            if (name == "" || passCode == NULL) 
			{
                System.out.println("All Field Required!");
                return false;
            }
            
            String sql = "select * from customer where cname='" + name + "' and pass_code=" + passCode;
            PreparedStatement st = con.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            
            BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
 
            if (rs.next()) 
			{
                int ch = 5;
				int amt = 0;
				int depAmount = 0;
				int wdrAmount = 0;
				
				int balance = 0;
                int senderAc = rs.getInt("ac_no");
           
                int receiveAc;
                while (true) 
				{
                    try 
					{
                        System.out.println("Hello, " + rs.getString("cname"));
                        System.out.println("1)Transfer Money");
                        System.out.println("2)View Balance");
						System.out.println("3)Deposite");
						System.out.println("4)Withdraw");
                        System.out.println("5)LogOut");
 
                        System.out.print("Enter Choice:");
                        ch = Integer.parseInt(sc.readLine());
                        if (ch == 1) 
						{
                            System.out.print("Enter Receiver  A/c No:");
                            receiveAc = Integer.parseInt(sc.readLine());
                            System.out.print("Enter Amount:");
                            amt = Integer.parseInt(sc.readLine());
 
                            if (BankManagement.transferMoney(senderAc, receiveAc,amt)) 
							{
                                System.out.println("Money Sent Successfully!");
                            }
                            else 
							{
                                System.out.println("Failed!");
                            }
                        }
                        else if (ch == 2) 
						{
							BankManagement.getBalance(senderAc);
                        }
						 else if (ch == 3) 
						{
							BankManagement.deposit();
                        }
						 else if (ch == 4) 
						{
							BankManagement.withdraw();
                        }
                        else if (ch == 5) 
						{
                            break;
                        }
                        else {
                            System.out.println(" Enter Valid input!");
                        }
                    }
                    catch (Exception e) 
					{
                        e.printStackTrace();
                    }
                }
            }
            else 
			{
                return false;
            }
           
            return true;
        }
        catch (SQLIntegrityConstraintViolationException e) 
		{
            System.out.println("Username Not Available!");
        }
        catch (Exception e) 
		{
            e.printStackTrace();
        }
        return false;
    }
    
	public static void getBalance(int acNo)
    {
        try {
             String sql = "select * from customer where ac_no=" + acNo;
            PreparedStatement st = con.prepareStatement(sql);
 
            ResultSet rs = st.executeQuery(sql);
            System.out.println("-----------------------------------------------------------");
            System.out.printf("%12s %10s %10s\n","Account No", "Name","Balance");
 
			while (rs.next()) 
			{
                System.out.printf("%12d %10s %10d.00\n",rs.getInt("ac_no"),
				rs.getString("cname"),
				rs.getInt("balance"));
            }
            System.out.println("-----------------------------------------------------------");
        }
        catch (Exception e) 
		{
            e.printStackTrace();
        }
    }
    
	public static boolean transferMoney(int sender_ac, int reveiver_ac, int amount) throws SQLException 
    {
        
        if (reveiver_ac == NULL || amount == NULL) 
		{
            System.out.println("All Field Required!");
            return false;
        }
        try 
		{
            con.setAutoCommit(false);
            String sql = "select * from customer where ac_no=" + sender_ac;
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
 
            if (rs.next()) 
			{
                if (rs.getInt("balance") < amount)
					{
                    System.out.println( " Insufficient Balance!");
                    return false;
                }
            }
 
            Statement st = con.createStatement();
 
            con.setSavepoint();//concept of savpoint for rollback.
 
            sql = "update customer set balance=balance-" + amount + " where ac_no=" + sender_ac;
            if (st.executeUpdate(sql) == 1) 
			{
				System.out.println("Amount Debited!");
            }
 
          
            sql = "update customer set balance=balance+" + amount + " where ac_no=" + reveiver_ac;
            st.executeUpdate(sql);
 
            con.commit();
            
        }catch (Exception e) 
		{
            e.printStackTrace();
            con.rollback();
        }
		return true;
		
	}	
static void deposit() throws SQLException
		{ 
		int balance = 0;
		int depAmount;
		int ac_no = 0;
		Scanner KB= new Scanner(System.in);
		System.out.println("Please enter your account No. ");
		ac_no = KB.nextInt();
        
		 
		PreparedStatement ps= con.prepareStatement("select balance from customer where ac_no=?");
		ps.setInt(1,ac_no);
		ResultSet rs1 = ps.executeQuery();
		
		if(rs1.next())
		{
			balance = rs1.getInt(1);
			
		}
		 
		 
         System.out.println("Enter Amount U Want to Deposit : ");
         depAmount = KB.nextInt();
		 
		 balance = balance + depAmount;
	
		
		PreparedStatement stmt2=con.prepareStatement("update customer set balance=? where ac_no= ?");
		stmt2.setInt(1,balance);
		stmt2.setInt(2,ac_no);
		 
            if (stmt2.executeUpdate() == 1) 
			{
				System.out.println("Amount Debited!");
            }
		 
		}

    //method to withdraw money
    static void withdraw() throws SQLException
	{	int balance = 0;
		int ac_no= 0;
		//System.out.println(ac_no);
		Scanner KB= new Scanner(System.in);
        int wdrAmount;
		
		 System.out.println("Please enter your account No. ");
		 ac_no = KB.nextInt();
		 
		 
		
        System.out.println("Enter Amount U Want to withdraw : ");
        wdrAmount = KB.nextInt();
		
		PreparedStatement ps2= con.prepareStatement("select balance from customer where ac_no=?");
		ps2.setInt(1,ac_no);
		ResultSet rs2 = ps2.executeQuery();
		
		if(rs2.next())
		{
			balance = rs2.getInt(1);
			
		}
		
        if (balance >= wdrAmount) 
		{ 
		   balance= balance - wdrAmount;
          String query= "update customer set balance=? where ac_no= ?";
		  PreparedStatement stmt2=con.prepareStatement(query);
		  stmt2.setInt(1,balance);
		  stmt2.setInt(2,ac_no);
		  
            if (stmt2.executeUpdate() == 1) 
			{
				System.out.println("Amount Debited!");
            }
        } 
		else 
		{
            System.out.println("Less Balance..Transaction Failed..");
        }
    }
        
      
    
}