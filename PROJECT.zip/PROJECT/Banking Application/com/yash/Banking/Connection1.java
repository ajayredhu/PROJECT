package com.yash.Banking;
 
import java.sql.*;
import java.sql.DriverManager;

public class Connection1 
{
    static Connection con;
    public static Connection getConnection()
    {
        try 
		{
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/bank"; //mysql url
            String user = "root";        //mysql username
            String pass = "root";  //mysql passcode
            
            con = DriverManager.getConnection(url, user, pass);
        }
        catch (Exception e) {
            System.out.println("Connection Failed!");
        }
 
        return con;
    }
}