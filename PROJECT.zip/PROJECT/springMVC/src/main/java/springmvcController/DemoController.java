package springmvcController;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DemoController {

	@RequestMapping("/home")
	public String home(Model model) {
		model.addAttribute("name", "Ajay");

		List<String> names = new ArrayList<String>();
		names.add("hello");
		names.add("Dhaval");
		model.addAttribute("names", names);

		return "index";

	}

	@RequestMapping("/display")
	public ModelAndView check(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView mv = new ModelAndView();
		mv.setViewName("display");
		mv.addObject("result", "Hii buddy");
		return mv;
	}

	@RequestMapping("/ab")
	public String about() {
		return "about";
	}

	@RequestMapping("/ms")
	public String myself() {
		return "myself";
	}

	@RequestMapping("/request")
	public String request() {
		return "request";
	}

	@RequestMapping(path = "/request", method = RequestMethod.POST)
	public String handlerequest(@RequestParam("name") String name,@RequestParam("email") String email, Model model) 
	{

		System.out.println(name);
		System.out.println(email);
		
		model.addAttribute("names", name);
		model.addAttribute("emailid", email);
		return "emailprint";
	}
	
			
}
	